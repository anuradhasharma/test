import React from 'react';
import * as d3 from "d3";
import reactDOM from "react-dom";
import "../loginSty.scss"; 


class Barchart extends React.Component {
    componentDidMount() {
        this.dsBarChart();
    }

    dsBarChart() {

        const data = [
            { letter: 'Fan', Watts: 20 },
            { letter: 'AC', Watts: 40 },
            { letter: 'Refrigerators', Watts: 50 },
            { letter: 'Light', Watts: 20 },
            { letter: 'Television', Watts: 40 },



        ];

        const margin = { top: 12, right: 23, bottom: 70, left: 12 };
        const width = 900 - margin.left - margin.right;
        const height = 261 - margin.top - margin.bottom


        const xScale = d3.scaleBand()
            .range([0, width])
            .round(true)
            .paddingInner(0.1); // space between bars (it's a ratio)

        const yScale = d3.scaleLinear()
            .range([height, 0]);

        const xAxis = d3.axisBottom()
            .scale(xScale).tickPadding(.4);

        const yAxis = d3.axisLeft()
            .scale(yScale)
            .ticks(10, '%');

        const svg = d3.select('#barChart')
            .append('svg')
            .attr('width', width + margin.left + margin.right)
            .attr('height', height + margin.top + margin.bottom)
            .append('g')
            .attr('transform', `translate(${margin.left}, ${margin.right})`);



        const tooltip = d3.select('#barChart').append('div')
            .attr('class', 'toolTip')
            .style('opacity', 0);

        xScale
            .domain(data.map(d => d.letter));
        yScale
            .domain([0, d3.max(data, d => d.Watts)]);

        svg.append('g')
            .attr('class', 'x axis')
            .attr('transform', `translate(0, ${height})`)
            .call(xAxis);

        svg.append('g')
            .attr('class', 'y axis')
            .call(yAxis)
            .append('text')
            .attr('transform', 'rotate(-90)')
            .attr('y', 6)
            .attr('dy', '.71em')
            .style('text-anchor', 'end')


        //tooltip
        svg.selectAll('.bar').data(data)
            .enter()
            .append('rect')
            .attr('class', 'bar')
            .attr('x', d => xScale(d.letter))
            .attr('width', xScale.bandwidth())
            .attr('y', d => yScale(d.Watts))
            .attr('height', d => height - yScale(d.Watts))
            .on('mouseover', (d) => {
                tooltip.transition().duration(200).style('opacity', 0.9);
                tooltip.html(`Watts: <span>${d.Watts}</span>`)
                    .style('left', `${d3.event.layerX}px`)
                    .style('top', `${(d3.event.layerY - 28)}px`);
            })

            .on('mouseout', () => tooltip.transition().duration(500).style('opacity', 0));

    }

    render() {

        return (<div id="barChart"></div>
        );

    }
}



export default Barchart