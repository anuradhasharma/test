
import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Card, Table } from 'antd';
import Fan from './Images/Fan.jfif';
import AC from './Images/AC.png';
import Refrigerator from './Images/Refrigerator.jpg';
import Lights from './Images/Lights.jpg';
import TV from './Images/TV.jpg';
import Switch from "react-switch";
import Barchart from './components/Barchart'
import Axios from 'axios';

const { Meta } = Card;
var energyControl = [{
  id: 1,
  name: 'Fan',
  energyConsumption: '22Wats',
  cost: 50,
  location: 'Room1',
  speed: '3',
  status: true
},
{
  id: 2,
  name: 'AC',
  energyConsumption: '40Wats',
  cost: 70,
  speed: '22',
  location: 'room1',
  status: true
},
{
  id: 3,
  name: 'Refrigerator',
  energyConsumption: '50Wats',
  location: 'kitchen',
  speed: 'cool',
  cost: 70,
  status: true
},
{
  id: 4,
  name: 'Lights',
  energyConsumption: '40Wats',
  cost: 70,
  speed: 'normal',
  location: 'room1',
  status: true
},
{
  id: 5,
  name: 'TV',
  energyConsumption: '40Wats',
  cost: 70,
  location: 'room1',
  speed: 'normal',
  status: true
}]

class App extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      billAmount: null,
    }
  }
  componentDidMount() {
    this.getAllInfo();
    this.CostCalculatorEngine();
  }
  getAllInfo = () => {
    axios.get()
      .then(response => {
        energyControl = response.data;
      }).catch(error => {

      })
  }
  onChangeStatus = (checked, id) => {
    let newData = JSON.parse(JSON.stringify(energyControl))
    newData.map((item) => {
      if (id = item.id) {
        item.status = checked
      }
    })


  }

  CostCalculatorEngine = () => {
    let billAmount = JSON.parse(JSON.stringify(energyControl))
    let billShowStatus = 'Month';
    let billCost = 0;
    billAmount.forEach(item => {
      if (billShowStatus == 'Month') {
        item.cost = item.cost * 30
        billCost += Number((item.cost))
      } else {
        billCost += Number(item.cost);
      }

    })
    this.setState({ billAmount: billCost })
  }
  render() {

    const columns = [
      {
        title: 'Appliances',
        dataIndex: 'name',
        align: 'left',
        width: 900,
        /*  render: (text, record) => {
           <span>{record.name}</span>
         } */

      },
      {
        title: 'Cost',
        dataIndex: 'cost',
        align: 'left',
        width: 150,
        /*   render: (text, record) => {
            <span>{record.cost}</span>
          } */

      }
    ]

    return (
      <div>

        <div class="jumbotron jumbotron-fluid">
          <div class="container">
            <h1 class="display-4"><Barchart /></h1>
            <p class="lead">Smart Home Energy Management System</p>
          </div>
        </div>


        <div className="row">
          {energyControl.map((item) => {
            return (
              <div className="col-sm-4 col-offset-1" style={{ marginTop: "2%" }}>
                <Card
                  className="card"
                  hoverable
                  cover={<img alt="example" src='./Images/AC.png' />}
                >
                  <div className="alignClass">Appliances : {item.name}</div>
                  <div className="alignClass">Energy Consumption : {item.energyConsumption}</div>
                  <div className="alignClass">Cost/perDay : {item.cost}</div>
                  <div className="alignClass">Location : {item.location}</div>
                  <div className="alignClass">Speed : {item.speed}</div>


                  <div style={{ textAlign: "center" }}>
                    Status: <Switch onChange={this.handleChange} checked={this.state.checked} />
                    {/* <Switch  onChange={(checked) => {
                      this.onChangeStatus(checked, item.id)

                    }}></Switch> */}
                  </div>
                </Card>
              </div>
            )
          })}
          <div className="col-sm-4 col-offset-1" style={{ marginTop: "2%" }}>
            <Card
              className="card"
              hoverable>
              <div style={{ textAlign: "center" }}><b>Expected Bill Amount</b></div>
              <div style={{ textAlign: "center" }}>
                {energyControl.map((item) => {
                  return <div>{item.name} : {item.cost}</div>
                })}
                <div>Total: {this.state.billAmount}</div>
              </div>
            </Card>
          </div>

        </div>
        <hr />
        <br />
        {/* <div className="row">
          <div style={{ color: "blue" }}> <b>Bill Amount</b></div>
          <div className="col-sm-10 col-sm-offset-1">

        

            <Table
              columns={columns} dataSource={energyControl}
              pagination={false}

            />
            <div className="row">
              <div className="col-sm-5 col-sm-offset-5">
                <span>Total  : </span> {this.state.billAmount}</div>
            </div>
          </div>
        </div> */}
      </div>
    );
  }
}

export default App;
